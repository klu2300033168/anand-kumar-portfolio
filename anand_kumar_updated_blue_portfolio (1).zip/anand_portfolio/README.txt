ANAND KUMAR — UPDATED BLUE PORTFOLIO

Open index.html in a browser to preview.

Included:
- Updated education, CGPA and expected graduation from the uploaded resume
- Resume-listed skills and tools
- Eduskills Foundation AI/ML internship
- Corn Leaf Disease Detection and AI for Personalized Retail Experience in AR
- Aviatrix and ServiceNow certifications
- Resume PDF download (if included in this package)

Before publishing:
- Add your GitHub and LinkedIn profile URLs.
- Add project repository/demo URLs and screenshots if available.
- Check that you are comfortable publishing the contact email and resume publicly.
- The resume file is included for the website download link.

Publish the folder using GitHub Pages, Netlify, or Vercel.
